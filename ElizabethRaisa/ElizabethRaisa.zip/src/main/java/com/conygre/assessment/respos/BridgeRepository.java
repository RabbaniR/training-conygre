package com.conygre.assessment.respos;

import com.conygre.assessment.entities.Bridge;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BridgeRepository extends JpaRepository<Bridge, Integer> {
}
