create database if not exists test1;
use  test1;
drop table bridge;
drop table cities;
#traffic_flow is in terms of millions
create table bridge  (id int primary key auto_increment, name varchar(50), max_traffic_flow double);
#cities are ordered by the more northern one first
create table cities (id int primary key auto_increment, bridge_id int not null, city1 varchar(50), city2 varchar(20), foreign key (bridge_id) references bridge(id));

insert into  bridge (name, max_traffic_flow) values ("Brooklyn", 5.1);
insert into  bridge (name, max_traffic_flow) values ("Manhattan", 3.9);
insert into  bridge (name, max_traffic_flow) values ("GW", 7.0);
insert into  bridge (name, max_traffic_flow) values ("Wittpenn", 4.2);

insert into cities (bridge_id, city1, city2) values (1, "Jersey City", "Kearny");
insert into cities (bridge_id, city1, city2) values (4, "Brooklyn", "Manhattan");
insert into cities (bridge_id, city1, city2) values (5, "Manhattan", "Fort Lee");
insert into cities (bridge_id, city1, city2) values (6, "Manhattan", "Brooklyn");





select * from bridge;
select * from cities;

